package model;

import java.util.ArrayList;

public class World {
	
	private Main mainJoueur1;
	

	public Main getMainJoueur1() {
		return mainJoueur1;
	}

	public World(Main mainJoueur1) {
		this.mainJoueur1 = mainJoueur1;
	}
	
	public static ArrayList<World> Generation(Partie p, int idJ1,int idJ2){
		
		ArrayList<World> liste = new ArrayList<World>();
		
		Main mj1=p.getJoueurs()[idJ2].getMain();
		
		//Construction de l'ensemble des cartes possibles pour la main du joueur
		ArrayList<Carte> cartesPossibles = p.getPioche();
		for(int i=0;i<(5-p.getJoueurs().length/3);i++)
		{
			try {
				cartesPossibles.add(mj1.getCarte(i));
			} catch (EnleverCarteInexistanteException e) {
				e.printStackTrace();
			}
		}
		//Construction d'une nouvelle liste que l'on va pour modifier sans toucher à la 1ere
		ArrayList<Carte> cartesPossiblesMod = new ArrayList<Carte>();
		cartesPossiblesMod.addAll(cartesPossibles);
		
		//Construction mondes
		Main m=new Main(p.getJoueurs().length);
		//horrible, inadapté au nb de cartes, mais provisoire
		for(int i1=0;i1<cartesPossibles.size()-4;i1++)
		{
			try {
				m.ajouterCarte(cartesPossibles.get(i1));
			} catch (AdditionMainPleineException e1) {
				e1.printStackTrace();
			}
			for(int i2=i1+1;i2<cartesPossibles.size()-3;i2++)
			{
				try {
					m.ajouterCarte(cartesPossibles.get(i2));
				} catch (AdditionMainPleineException e2) {
					e2.printStackTrace();
				}
				for(int i3=i2+1;i3<cartesPossibles.size()-2;i3++)
				{
					try {
						m.ajouterCarte(cartesPossibles.get(i3));
					} catch (AdditionMainPleineException e3) {
						e3.printStackTrace();
					}
					for(int i4=i3+1;i4<cartesPossibles.size()-1;i4++)
					{				
						try {
							m.ajouterCarte(cartesPossibles.get(i4));
						} catch (AdditionMainPleineException e4) {
							e4.printStackTrace();
						}
						for(int i5=i4+1;i5<cartesPossibles.size();i5++)
						{
							try {
								m.ajouterCarte(cartesPossibles.get(i5));
							} catch (AdditionMainPleineException e5) {
								e5.printStackTrace();
							}
							//test si main deja existante 
							World w=new World(m);
							if(w.inexistantDans(liste))
								liste.add(w);
						}
					}
				}
			}
		}
		return liste;
	}
	

	private boolean inexistantDans(ArrayList<World> liste) {
		for(int i=0; i<liste.size(); i++)
		{
			if(this.equals(liste.get(i)))
			{
				return false;
			}
		}
		
		return true;
	}

	private boolean equals(World world){
		
		Main m1=this.getMainJoueur1();
		Main m2=world.getMainJoueur1();
		int i=0; int j=0;
		Carte c1,c2=null;
		try {
			c1=m1.getCarte(i);
		} catch (EnleverCarteInexistanteException e) {
			e.printStackTrace();
		}
		try {
			c2=m2.getCarte(j);
		} catch (EnleverCarteInexistanteException e) {
			e.printStackTrace();
		}
		/*
		if(c1.equals(c2))
		{
			
		}
		*/
		return false;
	}
}
