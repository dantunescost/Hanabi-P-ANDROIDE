package model;

public class JoueurIA extends Joueur {

}
