package model;

public enum Couleur {
	BLANC, ROUGE, BLEU, VERT, JAUNE, MULTI
}
