# Hanabi-P-ANDROIDE

Ce projet consiste à développer un logiciel avec lequel on peut jouer coopérativement au jeu Hanabi.

Auteurs: Catalina Assmann, Cédric Hubert, Matthieu Wolfrom et Daniel Antunes
